# LatestWorld.in — GitHub Actions Secrets Guide
# Where to add secrets for automated cron jobs

============================================
HOW TO ADD SECRETS IN GITHUB
============================================

1. Go to your GitHub repository
2. Click "Settings" tab
3. Left sidebar → "Secrets and variables" → "Actions"
4. Click "New repository secret"
5. Add each secret below one by one

============================================
SECRETS TO ADD IN GITHUB
============================================

Name: SUPABASE_URL
Value: https://your-project.supabase.co
(Supabase → Settings → API → Project URL)

Name: SUPABASE_SERVICE_ROLE_KEY
Value: your-service-role-key
(Supabase → Settings → API → service_role key)

Name: COINGECKO_API_KEY
Value: CG-xxxxxxxxxxxxxxxxxx
(coingecko.com/en/developers/dashboard)

Name: GNEWS_API_KEY
Value: your-gnews-key
(gnews.io after signup)

Name: GH_TOKEN
Value: your-github-personal-access-token
(github.com/settings/tokens → Generate new token → public_repo scope)
NOTE: Use GH_TOKEN not GITHUB_TOKEN (GitHub reserves that name)

Name: PRODUCTHUNT_TOKEN
Value: your-product-hunt-token
(producthunt.com/v2/oauth/applications)

Name: ADZUNA_APP_ID
Value: your-adzuna-app-id
(developer.adzuna.com)

Name: ADZUNA_APP_KEY
Value: your-adzuna-app-key
(developer.adzuna.com)

Name: CLOUDFLARE_PAGES_DEPLOY_HOOK
Value: https://api.cloudflare.com/client/v4/pages/webhooks/deploy_hooks/XXXX
(Cloudflare Pages → Your project → Settings → Builds → Deploy Hooks → Add hook)

============================================
CRON SCHEDULE SUMMARY
============================================

Workflow File              Runs              What it does
crypto-update.yml          Every 6 hours     Crypto prices
news-update.yml            Every 6 hours     Tech news + Startup news
jobs-update.yml            Every 12 hours    Tech jobs
daily-update.yml           Daily at 1 AM     GitHub + AI Tools

============================================
HOW TO TEST MANUALLY
============================================

1. Go to GitHub → Actions tab
2. Click on any workflow name
3. Click "Run workflow" button (top right)
4. Click green "Run workflow" button
5. Watch the logs to verify it runs successfully

============================================
CLOUDFLARE PAGES — 2 ENVIRONMENT VARIABLES
============================================

Go to: Cloudflare → Pages → latestworld → Settings → Environment Variables

Add:
NEXT_PUBLIC_SUPABASE_URL     = https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = your-anon-key

Build settings:
  Framework preset: Next.js
  Build command:    npm run build
  Output directory: out
  Root directory:   (leave blank)
