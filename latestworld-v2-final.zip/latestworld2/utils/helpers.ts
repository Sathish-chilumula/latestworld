export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim()
    .substring(0, 80)
}

export function uniqueSlug(text: string, suffix?: string): string {
  const base = generateSlug(text)
  const ts = Date.now().toString(36)
  return suffix ? `${base}-${suffix}` : `${base}-${ts}`
}

export function formatPrice(price: number): string {
  if (price >= 1) return price.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return price.toFixed(6)
}

export function formatMarketCap(mc: number): string {
  if (mc >= 1e12) return `$${(mc / 1e12).toFixed(2)}T`
  if (mc >= 1e9) return `$${(mc / 1e9).toFixed(2)}B`
  if (mc >= 1e6) return `$${(mc / 1e6).toFixed(2)}M`
  return `$${mc.toLocaleString()}`
}

export function formatSalary(min: number, max: number): string {
  const toL = (n: number) => `₹${(n / 100000).toFixed(0)}L`
  if (!min && !max) return 'Salary not disclosed'
  if (!max) return `${toL(min)}+`
  return `${toL(min)} – ${toL(max)}/yr`
}

export function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  return `${days}d ago`
}

export function truncate(text: string, length = 120): string {
  if (!text) return ''
  return text.length > length ? text.substring(0, length) + '...' : text
}
