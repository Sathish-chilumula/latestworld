export default function ContactPage() {
  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '3rem 1.25rem' }}>
      <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem' }}>Contact Us</h1>
      <div style={{ background: '#e6162d', height: 4, width: 80, borderRadius: 4, marginBottom: '1.5rem' }} />
      <p style={{ color: '#6b7280', fontFamily: 'Poppins', marginBottom: '2rem' }}>Have a question, suggestion, or want to advertise? Reach out to us.</p>
      <div className="card" style={{ padding: '2rem' }}>
        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ display: 'block', fontFamily: 'Poppins', fontWeight: 600, fontSize: '13px', color: '#374151', marginBottom: '0.4rem' }}>Your Name</label>
          <input type="text" placeholder="Your full name" className="search-input" style={{ paddingLeft: '16px' }} />
        </div>
        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ display: 'block', fontFamily: 'Poppins', fontWeight: 600, fontSize: '13px', color: '#374151', marginBottom: '0.4rem' }}>Email Address</label>
          <input type="email" placeholder="you@example.com" className="search-input" style={{ paddingLeft: '16px' }} />
        </div>
        <div style={{ marginBottom: '1.5rem' }}>
          <label style={{ display: 'block', fontFamily: 'Poppins', fontWeight: 600, fontSize: '13px', color: '#374151', marginBottom: '0.4rem' }}>Message</label>
          <textarea rows={5} placeholder="Your message..." className="search-input" style={{ paddingLeft: '16px', paddingTop: '12px', resize: 'vertical', minHeight: 120 }} />
        </div>
        <p style={{ color: '#9ca3af', fontSize: '13px', fontFamily: 'Poppins', marginBottom: '1rem' }}>
          Or email directly: <a href="mailto:admin@latestworld.in" style={{ color: '#e6162d', fontWeight: 600 }}>admin@latestworld.in</a>
        </p>
      </div>
    </div>
  )
}
