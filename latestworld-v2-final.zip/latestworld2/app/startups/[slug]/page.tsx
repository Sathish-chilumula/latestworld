'use client'
import { useEffect, useState } from 'react'
import { getStartupNewsItem, type StartupNews } from '@/lib/supabase'
import { useParams } from 'next/navigation'

export default function StartupDetailPage() {
  const params = useParams()
  const [article, setArticle] = useState<StartupNews | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params?.slug) getStartupNewsItem(params.slug as string).then(setArticle).finally(() => setLoading(false))
  }, [params])

  if (loading) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div>
  if (!article) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Article not found</div>

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <a href="/startups" style={{ color: '#6b7280', textDecoration: 'none', fontFamily: 'Poppins', fontSize: '13px' }}>← Back to Startups</a>
      {article.image && <img src={article.image} alt={article.title} style={{ width: '100%', height: 340, objectFit: 'cover', borderRadius: 16, margin: '1.5rem 0' }} />}
      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap' }}>
        <span className="badge badge-startups">{article.source}</span>
        {article.funding_amount && <span style={{ background: '#ffedd5', color: '#ea580c', padding: '3px 12px', borderRadius: 999, fontFamily: 'Poppins', fontWeight: 700, fontSize: '13px' }}>💰 {article.funding_amount}</span>}
      </div>
      <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: 'clamp(1.4rem, 3vw, 2rem)', lineHeight: 1.3, marginBottom: '1.5rem', color: '#0f0f0f' }}>{article.title}</h1>
      <div style={{ borderLeft: '4px solid #ea580c', paddingLeft: '1.25rem', marginBottom: '2rem' }}>
        <p style={{ fontFamily: 'Merriweather', fontSize: '1.05rem', lineHeight: 1.8, color: '#374151' }}>{article.description}</p>
      </div>
      <a href={article.url} target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ background: '#ea580c' }}>Read Full Story →</a>
    </div>
  )
}
