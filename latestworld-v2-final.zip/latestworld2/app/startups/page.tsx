'use client'
import { useEffect, useState } from 'react'
import { getStartupNews, type StartupNews } from '@/lib/supabase'
import { timeAgo, truncate } from '@/utils/helpers'

export default function StartupsPage() {
  const [articles, setArticles] = useState<StartupNews[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { getStartupNews(60).then(setArticles).finally(() => setLoading(false)) }, [])

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <div style={{ background: 'linear-gradient(135deg, #ffedd5, #fff7ed)', border: '2px solid #ea580c30', borderRadius: 16, padding: '2rem', marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem' }}>🚀 Startup & Funding News</h1>
        <p style={{ color: '#374151', fontFamily: 'Poppins', fontSize: '14px' }}>Latest startup funding, launches and investment news — auto-updated every 6 hours</p>
      </div>
      {loading ? <div style={{ color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.25rem' }}>
          {articles.map(item => (
            <a key={item.slug} href={`/startups/${item.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
              <div className="card card-startups card-accent-startups" style={{ height: '100%' }}>
                {item.image && <img src={item.image} alt={item.title} style={{ width: '100%', height: 180, objectFit: 'cover' }} loading="lazy" />}
                <div style={{ padding: '1rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                    <span className="badge badge-startups">{item.source}</span>
                    <span style={{ color: '#9ca3af', fontSize: '11px', fontFamily: 'Poppins' }}>{timeAgo(item.published_at)}</span>
                  </div>
                  <h3 style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '14px', lineHeight: 1.4, color: '#0f0f0f', marginBottom: '0.5rem' }}>{item.title}</h3>
                  <p style={{ color: '#6b7280', fontSize: '12px', lineHeight: 1.6, marginBottom: '0.75rem' }}>{truncate(item.description, 100)}</p>
                  {item.funding_amount && (
                    <span style={{ background: '#ffedd5', color: '#ea580c', padding: '3px 10px', borderRadius: 999, fontSize: '12px', fontWeight: 700, fontFamily: 'Poppins' }}>💰 {item.funding_amount}</span>
                  )}
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}
