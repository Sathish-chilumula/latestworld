'use client'
import { useEffect, useState } from 'react'
import { getAITools, type AITool } from '@/lib/supabase'
import { truncate } from '@/utils/helpers'

export default function AIToolsPage() {
  const [tools, setTools] = useState<AITool[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { getAITools(80).then(setTools).finally(() => setLoading(false)) }, [])

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <div style={{ background: 'linear-gradient(135deg, #ede9fe, #f5f3ff)', border: '2px solid #7c3aed30', borderRadius: 16, padding: '2rem', marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem' }}>🤖 Latest AI Tools</h1>
        <p style={{ color: '#6b7280', fontFamily: 'Poppins', fontSize: '14px' }}>Newly launched AI tools from Product Hunt — updated daily</p>
      </div>
      {loading ? <div style={{ color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
          {tools.map(tool => (
            <a key={tool.slug} href={`/ai-tools/${tool.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
              <div className="card card-aitools" style={{ padding: '1.25rem', display: 'flex', gap: '1rem', alignItems: 'flex-start', height: '100%' }}>
                {tool.image
                  ? <img src={tool.image} alt={tool.name} width={52} height={52} style={{ borderRadius: 12, objectFit: 'cover', flexShrink: 0 }} />
                  : <div style={{ width: 52, height: 52, background: '#ede9fe', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', flexShrink: 0 }}>🤖</div>
                }
                <div>
                  <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '15px', marginBottom: '0.3rem', color: '#0f0f0f' }}>{tool.name}</div>
                  <div style={{ color: '#6b7280', fontSize: '12px', lineHeight: 1.6, marginBottom: '0.5rem' }}>{truncate(tool.tagline || tool.description, 80)}</div>
                  <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                    <span className="badge badge-aitools">{tool.category || 'AI'}</span>
                    {tool.votes > 0 && <span style={{ color: '#7c3aed', fontSize: '12px', fontWeight: 700, fontFamily: 'Poppins' }}>▲ {tool.votes}</span>}
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}
