'use client'
import { useEffect, useState } from 'react'
import { getAITool, type AITool } from '@/lib/supabase'
import { useParams } from 'next/navigation'

export default function AIToolDetailPage() {
  const params = useParams()
  const [tool, setTool] = useState<AITool | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params?.slug) getAITool(params.slug as string).then(setTool).finally(() => setLoading(false))
  }, [params])

  if (loading) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div>
  if (!tool) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Tool not found</div>

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <a href="/ai-tools" style={{ color: '#6b7280', textDecoration: 'none', fontFamily: 'Poppins', fontSize: '13px' }}>← Back to AI Tools</a>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', margin: '1.5rem 0' }}>
        {tool.image
          ? <img src={tool.image} alt={tool.name} width={80} height={80} style={{ borderRadius: 16, objectFit: 'cover' }} />
          : <div style={{ width: 80, height: 80, background: '#ede9fe', borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem' }}>🤖</div>
        }
        <div>
          <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', color: '#0f0f0f', marginBottom: '0.25rem' }}>{tool.name}</h1>
          <p style={{ color: '#6b7280', fontFamily: 'Poppins', fontSize: '15px' }}>{tool.tagline}</p>
          {tool.votes > 0 && <div style={{ color: '#7c3aed', fontWeight: 700, fontSize: '14px', fontFamily: 'Poppins', marginTop: '0.25rem' }}>▲ {tool.votes} upvotes on Product Hunt</div>}
        </div>
      </div>
      <div className="card" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <h2 style={{ fontFamily: 'Poppins', fontWeight: 700, marginBottom: '0.75rem' }}>About {tool.name}</h2>
        <p style={{ color: '#374151', lineHeight: 1.8, fontFamily: 'Merriweather' }}>{tool.description || tool.tagline}</p>
        {tool.category && <span className="badge badge-aitools" style={{ marginTop: '1rem', display: 'inline-block' }}>{tool.category}</span>}
      </div>
      {tool.website && <a href={tool.website} target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ background: '#7c3aed' }}>Visit {tool.name} →</a>}
    </div>
  )
}
