import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  metadataBase: new URL('https://latestworld.in'),
  title: {
    default: 'LatestWorld — Tech News, Crypto, AI Tools & Jobs in India',
    template: '%s | LatestWorld'
  },
  description: 'Stay ahead with live cryptocurrency prices, latest tech news, AI tools, trending GitHub projects, startup funding news, and tech jobs in India — updated automatically.',
  keywords: ['tech news India', 'crypto prices India', 'AI tools 2024', 'GitHub trending', 'startup funding India', 'tech jobs Bangalore'],
  authors: [{ name: 'LatestWorld' }],
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://latestworld.in',
    siteName: 'LatestWorld',
    images: [{ url: '/og.png', width: 1200, height: 630 }]
  },
  twitter: { card: 'summary_large_image', site: '@latestworld_in' },
  robots: { index: true, follow: true }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        {/* Google AdSense — add your publisher ID after approval */}
        {/* <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXX" crossOrigin="anonymous"></script> */}
      </head>
      <body>
        <BreakingTicker />
        <Header />
        <main style={{ minHeight: '80vh' }}>{children}</main>
        <Footer />
      </body>
    </html>
  )
}

function BreakingTicker() {
  const items = [
    '🔴 LIVE: Crypto markets updating every 6 hours',
    '📰 Latest tech news from India and worldwide',
    '🤖 New AI tools launching daily on Product Hunt',
    '💼 Fresh tech jobs updated twice daily',
    '⭐ GitHub trending projects updated every day',
    '🚀 Startup funding news — India & Global',
  ]
  const doubled = [...items, ...items]
  return (
    <div className="ticker-wrapper">
      <div className="ticker-label">🔴 LIVE</div>
      <div style={{ overflow: 'hidden', flex: 1 }}>
        <div className="ticker-track">
          {doubled.map((item, i) => (
            <span key={i} className="ticker-item">{item}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

function Header() {
  return (
    <header style={{ background: '#fff', borderBottom: '3px solid #e6162d', position: 'sticky', top: 0, zIndex: 100, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 1.25rem', display: 'flex', alignItems: 'center', height: 64, gap: '2rem' }}>
        {/* Logo */}
        <a href="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
          <div style={{ background: '#e6162d', color: 'white', width: 36, height: 36, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Poppins', fontWeight: 900, fontSize: '1.1rem' }}>L</div>
          <div>
            <div style={{ fontFamily: 'Poppins', fontWeight: 800, fontSize: '1.1rem', color: '#0f0f0f', lineHeight: 1 }}>LatestWorld</div>
            <div style={{ fontFamily: 'Poppins', fontSize: '10px', color: '#e6162d', fontWeight: 600, letterSpacing: '0.08em' }}>LATESTWORLD.IN</div>
          </div>
        </a>

        {/* Nav */}
        <nav style={{ display: 'flex', gap: '0.25rem', alignItems: 'center', flex: 1, overflowX: 'auto' }}>
          {[
            { href: '/crypto', label: '💹 Crypto', color: '#f59e0b' },
            { href: '/news', label: '📰 News', color: '#e6162d' },
            { href: '/ai-tools', label: '🤖 AI Tools', color: '#7c3aed' },
            { href: '/github', label: '⭐ GitHub', color: '#16a34a' },
            { href: '/jobs', label: '💼 Jobs', color: '#2563eb' },
            { href: '/startups', label: '🚀 Startups', color: '#ea580c' },
          ].map(nav => (
            <a key={nav.href} href={nav.href} style={{
              textDecoration: 'none', padding: '6px 12px', borderRadius: 8,
              fontFamily: 'Poppins', fontWeight: 600, fontSize: '13px',
              color: '#374151', whiteSpace: 'nowrap',
              transition: 'all 0.15s'
            }}
              onMouseOver={e => { (e.target as HTMLElement).style.background = '#f3f4f6'; (e.target as HTMLElement).style.color = nav.color }}
              onMouseOut={e => { (e.target as HTMLElement).style.background = 'transparent'; (e.target as HTMLElement).style.color = '#374151' }}
            >
              {nav.label}
            </a>
          ))}
        </nav>

        {/* Live badge */}
        <div className="live-badge" style={{ flexShrink: 0 }}>
          <span className="live-dot" />
          LIVE
        </div>
      </div>
    </header>
  )
}

function Footer() {
  return (
    <footer style={{ background: '#0f0f0f', color: '#9ca3af', marginTop: '5rem' }}>
      {/* Top footer */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '3rem 1.25rem', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '1rem' }}>
            <div style={{ background: '#e6162d', color: 'white', width: 32, height: 32, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Poppins', fontWeight: 900 }}>L</div>
            <span style={{ fontFamily: 'Poppins', fontWeight: 800, color: 'white', fontSize: '1rem' }}>LatestWorld</span>
          </div>
          <p style={{ fontSize: '13px', lineHeight: 1.7 }}>Your daily automated tech intelligence hub for India and the world.</p>
        </div>
        <div>
          <div style={{ fontFamily: 'Poppins', fontWeight: 700, color: 'white', marginBottom: '0.75rem', fontSize: '14px' }}>Sections</div>
          {[['💹 Crypto', '/crypto'], ['📰 Tech News', '/news'], ['🤖 AI Tools', '/ai-tools'], ['⭐ GitHub', '/github']].map(([label, href]) => (
            <a key={href} href={href} style={{ display: 'block', color: '#9ca3af', textDecoration: 'none', fontSize: '13px', marginBottom: '0.35rem', fontFamily: 'Poppins' }}>{label}</a>
          ))}
        </div>
        <div>
          <div style={{ fontFamily: 'Poppins', fontWeight: 700, color: 'white', marginBottom: '0.75rem', fontSize: '14px' }}>More</div>
          {[['💼 Tech Jobs', '/jobs'], ['🚀 Startups', '/startups'], ['About', '/about'], ['Privacy Policy', '/privacy-policy'], ['Contact', '/contact']].map(([label, href]) => (
            <a key={href} href={href} style={{ display: 'block', color: '#9ca3af', textDecoration: 'none', fontSize: '13px', marginBottom: '0.35rem', fontFamily: 'Poppins' }}>{label}</a>
          ))}
        </div>
        <div>
          <div style={{ fontFamily: 'Poppins', fontWeight: 700, color: 'white', marginBottom: '0.75rem', fontSize: '14px' }}>Data Sources</div>
          <div style={{ fontSize: '12px', lineHeight: 1.8 }}>
            <div>Crypto: <a href="https://www.coingecko.com?utm_source=latestworld&utm_medium=referral" target="_blank" rel="noopener noreferrer" style={{ color: '#f59e0b' }}>CoinGecko</a></div>
            <div>News: GNews API</div>
            <div>AI Tools: Product Hunt</div>
            <div>Jobs: Adzuna</div>
            <div>Projects: GitHub API</div>
          </div>
        </div>
      </div>
      {/* Bottom bar */}
      <div style={{ borderTop: '1px solid #1f2937', padding: '1.25rem', textAlign: 'center', fontSize: '12px', fontFamily: 'Poppins' }}>
        © {new Date().getFullYear()} LatestWorld.in — Automated technology intelligence. All data updated automatically.
      </div>
    </footer>
  )
}
