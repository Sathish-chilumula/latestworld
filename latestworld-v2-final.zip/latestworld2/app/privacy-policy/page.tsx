export default function PrivacyPage() {
  const sections = [
    ['Information We Collect', 'LatestWorld.in does not collect any personally identifiable information from visitors. We do not require user registration or login. The site is purely informational.'],
    ['Cookies & Advertising', 'We use Google AdSense to display relevant advertisements. Google AdSense uses cookies to serve personalised ads based on your browsing history. You can opt out at Google\'s Ads Settings page.'],
    ['Third-Party Data', 'All data on LatestWorld.in is sourced from third-party APIs including CoinGecko, GNews, GitHub, Product Hunt, and Adzuna. Please refer to their privacy policies for details on their data practices.'],
    ['Analytics', 'We may use anonymous analytics services to understand how visitors use our site. This data is aggregated and does not identify individuals.'],
    ['External Links', 'Our site contains links to external websites. We are not responsible for the privacy practices of those websites.'],
    ['Changes', 'We may update this Privacy Policy from time to time. We encourage you to review this page periodically for changes.'],
  ]

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '3rem 1.25rem' }}>
      <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem' }}>Privacy Policy</h1>
      <div style={{ background: '#e6162d', height: 4, width: 80, borderRadius: 4, marginBottom: '0.5rem' }} />
      <p style={{ color: '#9ca3af', fontFamily: 'Poppins', fontSize: '13px', marginBottom: '2rem' }}>Last updated: {new Date().toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      {sections.map(([title, content]) => (
        <div key={title} style={{ marginBottom: '1.75rem' }}>
          <h2 style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '1.1rem', marginBottom: '0.5rem', color: '#0f0f0f' }}>{title}</h2>
          <p style={{ color: '#374151', lineHeight: 1.8, fontFamily: 'Merriweather', fontSize: '14px' }}>{content}</p>
        </div>
      ))}
      <p style={{ color: '#374151', fontFamily: 'Merriweather', fontSize: '14px' }}>
        For questions, contact us via our <a href="/contact" style={{ color: '#e6162d', fontWeight: 600 }}>Contact page</a>.
      </p>
    </div>
  )
}
