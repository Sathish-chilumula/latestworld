import { supabase } from '@/lib/supabase'

export default async function sitemap() {
  const base = 'https://latestworld.in'

  const statics = [
    { url: base, lastModified: new Date(), changeFrequency: 'daily' as const, priority: 1 },
    { url: `${base}/crypto`, changeFrequency: 'hourly' as const, priority: 0.9 },
    { url: `${base}/news`, changeFrequency: 'hourly' as const, priority: 0.9 },
    { url: `${base}/jobs`, changeFrequency: 'daily' as const, priority: 0.9 },
    { url: `${base}/ai-tools`, changeFrequency: 'daily' as const, priority: 0.8 },
    { url: `${base}/github`, changeFrequency: 'daily' as const, priority: 0.8 },
    { url: `${base}/startups`, changeFrequency: 'hourly' as const, priority: 0.8 },
    { url: `${base}/about`, changeFrequency: 'monthly' as const, priority: 0.4 },
    { url: `${base}/privacy-policy`, changeFrequency: 'monthly' as const, priority: 0.3 },
    { url: `${base}/contact`, changeFrequency: 'monthly' as const, priority: 0.3 },
  ]

  const dynamics: any[] = []

  try {
    const [crypto, news, jobs, github, aitools, startups] = await Promise.all([
      supabase.from('crypto_coins').select('slug,updated_at').limit(200),
      supabase.from('tech_news').select('slug,published_at').limit(1000),
      supabase.from('jobs').select('slug,created_at').limit(1000),
      supabase.from('github_projects').select('slug,updated_at').limit(500),
      supabase.from('ai_tools').select('slug,created_at').limit(500),
      supabase.from('startup_news').select('slug,published_at').limit(1000),
    ])

    crypto.data?.forEach(r => dynamics.push({ url: `${base}/crypto/${r.slug}`, lastModified: new Date(r.updated_at), changeFrequency: 'hourly' as const, priority: 0.7 }))
    news.data?.forEach(r => dynamics.push({ url: `${base}/news/${r.slug}`, lastModified: new Date(r.published_at), changeFrequency: 'daily' as const, priority: 0.7 }))
    jobs.data?.forEach(r => dynamics.push({ url: `${base}/jobs/${r.slug}`, lastModified: new Date(r.created_at), changeFrequency: 'daily' as const, priority: 0.7 }))
    github.data?.forEach(r => dynamics.push({ url: `${base}/github/${r.slug}`, lastModified: new Date(r.updated_at), changeFrequency: 'daily' as const, priority: 0.6 }))
    aitools.data?.forEach(r => dynamics.push({ url: `${base}/ai-tools/${r.slug}`, lastModified: new Date(r.created_at), changeFrequency: 'daily' as const, priority: 0.6 }))
    startups.data?.forEach(r => dynamics.push({ url: `${base}/startups/${r.slug}`, lastModified: new Date(r.published_at), changeFrequency: 'daily' as const, priority: 0.7 }))
  } catch (e) { console.error('Sitemap error:', e) }

  return [...statics, ...dynamics]
}
