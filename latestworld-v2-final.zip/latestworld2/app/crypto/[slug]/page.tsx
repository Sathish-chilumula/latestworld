'use client'
import { useEffect, useState } from 'react'
import { getCryptoCoin, type CryptoCoin } from '@/lib/supabase'
import { formatPrice, formatMarketCap } from '@/utils/helpers'
import { useParams } from 'next/navigation'

export default function CoinPage() {
  const params = useParams()
  const [coin, setCoin] = useState<CryptoCoin | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params?.slug) getCryptoCoin(params.slug as string).then(setCoin).finally(() => setLoading(false))
  }, [params])

  if (loading) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div>
  if (!coin) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Coin not found</div>

  const isUp = (coin.change_24h || 0) >= 0

  return (
    <div style={{ maxWidth: 960, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FinancialProduct",
        "name": `${coin.name} (${coin.symbol}) Price`,
        "description": `${coin.name} current price $${formatPrice(coin.price)}, market cap ${formatMarketCap(coin.market_cap)}, 24h change ${coin.change_24h?.toFixed(2)}%`,
        "url": `https://latestworld.in/crypto/${coin.slug}`
      })}} />

      <a href="/crypto" style={{ color: '#6b7280', textDecoration: 'none', fontFamily: 'Poppins', fontSize: '13px' }}>← Back to Crypto</a>

      <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', margin: '1.5rem 0' }}>
        {coin.image && <img src={coin.image} alt={coin.name} width={64} height={64} style={{ borderRadius: '50%' }} />}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', margin: 0 }}>{coin.name}</h1>
            <span style={{ background: '#f3f4f6', color: '#6b7280', padding: '3px 10px', borderRadius: 6, fontFamily: 'Poppins', fontWeight: 700, fontSize: '14px' }}>{coin.symbol}</span>
          </div>
          <div style={{ color: '#9ca3af', fontFamily: 'Poppins', fontSize: '13px' }}>Rank #{coin.market_cap_rank}</div>
        </div>
      </div>

      {/* Price hero */}
      <div style={{ background: 'linear-gradient(135deg, #f59e0b15, #f59e0b05)', border: '2px solid #f59e0b30', borderRadius: 16, padding: '1.5rem 2rem', marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '2rem', flexWrap: 'wrap' }}>
        <div>
          <div style={{ color: '#9ca3af', fontFamily: 'Poppins', fontSize: '12px', fontWeight: 600, marginBottom: '0.25rem' }}>CURRENT PRICE</div>
          <div style={{ fontFamily: 'JetBrains Mono', fontWeight: 700, fontSize: '2.5rem', color: '#0f0f0f' }}>${formatPrice(coin.price)}</div>
        </div>
        <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
          <StatBox label="24h Change" value={`${isUp ? '▲' : '▼'} ${Math.abs(coin.change_24h || 0).toFixed(2)}%`} color={isUp ? '#16a34a' : '#dc2626'} />
          <StatBox label="7d Change" value={`${(coin.change_7d || 0) >= 0 ? '▲' : '▼'} ${Math.abs(coin.change_7d || 0).toFixed(2)}%`} color={(coin.change_7d || 0) >= 0 ? '#16a34a' : '#dc2626'} />
          <StatBox label="Market Cap" value={formatMarketCap(coin.market_cap)} />
          <StatBox label="24h Volume" value={formatMarketCap(coin.volume_24h)} />
        </div>
      </div>

      <div className="card" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <h2 style={{ fontFamily: 'Poppins', fontWeight: 700, marginBottom: '0.75rem', fontSize: '1.1rem' }}>About {coin.name}</h2>
        <p style={{ color: '#374151', lineHeight: 1.8, fontFamily: 'Merriweather', fontSize: '15px' }}>
          {coin.name} ({coin.symbol}) is a cryptocurrency currently ranked #{coin.market_cap_rank} by market capitalisation.
          The current {coin.name} price is <strong>${formatPrice(coin.price)} USD</strong>, with a 24-hour change
          of <span style={{ color: isUp ? '#16a34a' : '#dc2626', fontWeight: 600 }}>{coin.change_24h?.toFixed(2)}%</span>.
          The total market capitalisation stands at {formatMarketCap(coin.market_cap)}.
          Data is automatically updated every 6 hours from CoinGecko.
        </p>
      </div>

      <p style={{ color: '#9ca3af', fontSize: '12px', fontFamily: 'Poppins' }}>
        Price data by <a href="https://www.coingecko.com?utm_source=latestworld&utm_medium=referral" target="_blank" rel="noopener noreferrer" style={{ color: '#16a34a', fontWeight: 700 }}>CoinGecko</a>
      </p>
    </div>
  )
}

function StatBox({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div>
      <div style={{ color: '#9ca3af', fontFamily: 'Poppins', fontSize: '11px', fontWeight: 600, marginBottom: '0.25rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
      <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '1rem', color: color || '#0f0f0f' }}>{value}</div>
    </div>
  )
}
