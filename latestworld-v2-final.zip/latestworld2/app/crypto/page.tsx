'use client'
import { useEffect, useState } from 'react'
import { getCryptoCoins, type CryptoCoin } from '@/lib/supabase'
import { formatPrice, formatMarketCap } from '@/utils/helpers'

export default function CryptoPage() {
  const [coins, setCoins] = useState<CryptoCoin[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => { getCryptoCoins(100).then(setCoins).finally(() => setLoading(false)) }, [])

  const filtered = coins.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.symbol.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: '0.5rem' }}>
          <h1 style={{ fontFamily: 'Poppins', fontWeight: 800, fontSize: '2rem' }}>💹 Cryptocurrency Prices</h1>
          <span className="live-badge"><span className="live-dot" /> LIVE</span>
        </div>
        <p style={{ color: '#6b7280', fontFamily: 'Poppins', fontSize: '14px' }}>Live crypto market data — updated every 6 hours via CoinGecko</p>
      </div>

      <div style={{ position: 'relative', maxWidth: 420, marginBottom: '1.5rem' }}>
        <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af' }}>🔍</span>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search coins..." className="search-input" />
      </div>

      <div className="card" style={{ overflow: 'hidden' }}>
        <table className="crypto-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Coin</th>
              <th style={{ textAlign: 'right' }}>Price (USD)</th>
              <th style={{ textAlign: 'right' }}>24h Change</th>
              <th style={{ textAlign: 'right' }}>7d Change</th>
              <th style={{ textAlign: 'right' }}>Market Cap</th>
              <th style={{ textAlign: 'right' }}>Volume 24h</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 10 }).map((_, i) => (
                <tr key={i}><td colSpan={7}><div style={{ height: 20, background: '#f3f4f6', borderRadius: 4, margin: '4px 0' }} /></td></tr>
              ))
            ) : filtered.map(coin => (
              <tr key={coin.slug} onClick={() => window.location.href = `/crypto/${coin.slug}`}>
                <td style={{ color: '#9ca3af', fontWeight: 600 }}>{coin.market_cap_rank}</td>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    {coin.image && <img src={coin.image} alt={coin.name} width={32} height={32} style={{ borderRadius: '50%' }} />}
                    <div>
                      <div style={{ fontWeight: 700 }}>{coin.name}</div>
                      <div style={{ color: '#9ca3af', fontSize: '11px', fontWeight: 600 }}>{coin.symbol}</div>
                    </div>
                  </div>
                </td>
                <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontWeight: 700 }}>${formatPrice(coin.price)}</td>
                <td style={{ textAlign: 'right' }}>
                  <span className={coin.change_24h >= 0 ? 'price-up' : 'price-down'}>
                    {coin.change_24h >= 0 ? '▲' : '▼'} {Math.abs(coin.change_24h || 0).toFixed(2)}%
                  </span>
                </td>
                <td style={{ textAlign: 'right' }}>
                  <span className={(coin.change_7d || 0) >= 0 ? 'price-up' : 'price-down'}>
                    {(coin.change_7d || 0) >= 0 ? '▲' : '▼'} {Math.abs(coin.change_7d || 0).toFixed(2)}%
                  </span>
                </td>
                <td style={{ textAlign: 'right', color: '#6b7280' }}>{formatMarketCap(coin.market_cap)}</td>
                <td style={{ textAlign: 'right', color: '#6b7280' }}>{formatMarketCap(coin.volume_24h)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: '1.5rem', padding: '0.75rem 1rem', background: '#f7f8fa', borderRadius: 8, display: 'flex', alignItems: 'center', gap: 8, fontSize: '12px', color: '#6b7280', fontFamily: 'Poppins' }}>
        Crypto data provided by <a href="https://www.coingecko.com?utm_source=latestworld&utm_medium=referral" target="_blank" rel="noopener noreferrer" style={{ color: '#16a34a', fontWeight: 700 }}>CoinGecko</a>
      </div>
    </div>
  )
}
