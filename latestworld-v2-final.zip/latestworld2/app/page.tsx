'use client'
import { useEffect, useState } from 'react'
import { getHomepageData } from '@/lib/supabase'
import type { CryptoCoin, TechNews, Job, AITool, GithubProject, StartupNews } from '@/lib/supabase'
import { formatPrice, formatMarketCap, formatSalary, timeAgo, truncate } from '@/utils/helpers'

export default function HomePage() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getHomepageData().then(setData).catch(console.error).finally(() => setLoading(false))
  }, [])

  if (loading) return <LoadingSkeleton />

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>

      {/* Hero */}
      <div style={{ background: 'linear-gradient(135deg, #e6162d 0%, #b30f20 100%)', borderRadius: 16, padding: '2.5rem 2rem', marginBottom: '2.5rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', right: -40, top: -40, width: 300, height: 300, background: 'rgba(255,255,255,0.05)', borderRadius: '50%' }} />
        <div style={{ position: 'relative' }}>
          <div className="live-badge" style={{ background: 'rgba(255,255,255,0.2)', color: 'white', marginBottom: '1rem', display: 'inline-flex' }}>
            <span style={{ width: 7, height: 7, background: 'white', borderRadius: '50%', animation: 'pulseDot 1.5s infinite' }} />
            AUTO-UPDATED
          </div>
          <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: 'clamp(1.8rem, 4vw, 3rem)', color: 'white', lineHeight: 1.2, marginBottom: '0.75rem' }}>
            India's #1 Tech<br />Intelligence Hub
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '1rem', maxWidth: 500, fontFamily: 'Poppins', fontWeight: 400 }}>
            Crypto · News · AI Tools · GitHub · Jobs · Startups — Everything updates automatically, no manual effort.
          </p>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem', flexWrap: 'wrap' }}>
            {[
              { label: '100+ Coins', icon: '💹' },
              { label: '50+ Jobs/day', icon: '💼' },
              { label: '20+ News/day', icon: '📰' },
              { label: '10+ AI Tools/day', icon: '🤖' },
            ].map(stat => (
              <div key={stat.label} style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(4px)', borderRadius: 8, padding: '8px 16px', color: 'white', fontFamily: 'Poppins', fontSize: '13px', fontWeight: 600 }}>
                {stat.icon} {stat.label}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Crypto Ticker Strip */}
      {data?.crypto?.length > 0 && (
        <div style={{ background: '#0f0f0f', borderRadius: 10, padding: '12px 0', marginBottom: '2.5rem', overflow: 'hidden' }}>
          <div style={{ display: 'flex', animation: 'ticker 20s linear infinite', whiteSpace: 'nowrap' }}>
            {[...data.crypto, ...data.crypto].map((coin: CryptoCoin, i: number) => (
              <a key={i} href={`/crypto/${coin.slug}`} style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 8, padding: '0 24px', borderRight: '1px solid #1f2937' }}>
                {coin.image && <img src={coin.image} alt={coin.name} width={20} height={20} style={{ borderRadius: '50%' }} />}
                <span style={{ fontFamily: 'Poppins', fontWeight: 700, color: 'white', fontSize: '13px' }}>{coin.symbol}</span>
                <span style={{ fontFamily: 'JetBrains Mono', color: '#e2e8f0', fontSize: '13px' }}>${formatPrice(coin.price)}</span>
                <span style={{ fontFamily: 'Poppins', fontSize: '11px', fontWeight: 600, color: coin.change_24h >= 0 ? '#22c55e' : '#ef4444' }}>
                  {coin.change_24h >= 0 ? '▲' : '▼'}{Math.abs(coin.change_24h || 0).toFixed(2)}%
                </span>
              </a>
            ))}
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '2rem', alignItems: 'start' }}>
        <div>
          {/* Crypto Section */}
          <Section title="💹 Crypto Market" href="/crypto" accent="crypto" badge="Live">
            <div style={{ overflowX: 'auto' }}>
              <table className="crypto-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Coin</th>
                    <th style={{ textAlign: 'right' }}>Price</th>
                    <th style={{ textAlign: 'right' }}>24h</th>
                    <th style={{ textAlign: 'right' }} className="hide-mobile">Market Cap</th>
                  </tr>
                </thead>
                <tbody>
                  {data?.crypto?.map((coin: CryptoCoin) => (
                    <tr key={coin.slug} onClick={() => window.location.href = `/crypto/${coin.slug}`}>
                      <td style={{ color: '#9ca3af', fontWeight: 600 }}>{coin.market_cap_rank}</td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          {coin.image && <img src={coin.image} alt={coin.name} width={28} height={28} style={{ borderRadius: '50%' }} />}
                          <div>
                            <div style={{ fontWeight: 700, fontSize: '14px' }}>{coin.name}</div>
                            <div style={{ color: '#9ca3af', fontSize: '11px', fontWeight: 500 }}>{coin.symbol}</div>
                          </div>
                        </div>
                      </td>
                      <td style={{ textAlign: 'right', fontFamily: 'JetBrains Mono', fontWeight: 700 }}>${formatPrice(coin.price)}</td>
                      <td style={{ textAlign: 'right' }}>
                        <span className={coin.change_24h >= 0 ? 'price-up' : 'price-down'}>
                          {coin.change_24h >= 0 ? '▲' : '▼'} {Math.abs(coin.change_24h || 0).toFixed(2)}%
                        </span>
                      </td>
                      <td style={{ textAlign: 'right', color: '#6b7280' }} className="hide-mobile">{formatMarketCap(coin.market_cap)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>

          {/* Tech News */}
          <Section title="📰 Latest Tech News" href="/news" accent="news">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
              {data?.news?.map((item: TechNews, i: number) => (
                <a key={item.slug} href={`/news/${item.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
                  <div className="card card-news card-accent-news">
                    {item.image && <img src={item.image} alt={item.title} style={{ width: '100%', height: 160, objectFit: 'cover' }} loading="lazy" />}
                    <div style={{ padding: '1rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                        <span className="badge badge-news">{item.source}</span>
                        <span style={{ color: '#9ca3af', fontSize: '11px', fontFamily: 'Poppins' }}>{timeAgo(item.published_at)}</span>
                      </div>
                      <h3 style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '14px', lineHeight: 1.4, color: '#0f0f0f', marginBottom: '0.4rem' }}>{item.title}</h3>
                      <p style={{ color: '#6b7280', fontSize: '12px', lineHeight: 1.6, fontFamily: 'Merriweather' }}>{truncate(item.description, 100)}</p>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </Section>

          {/* GitHub Projects */}
          <Section title="⭐ Trending GitHub Projects" href="/github" accent="github">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
              {data?.github?.map((repo: GithubProject) => (
                <a key={repo.slug} href={`/github/${repo.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
                  <div className="card card-github card-accent-github" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '0.75rem' }}>
                      {repo.avatar_url && <img src={repo.avatar_url} alt={repo.owner} width={22} height={22} style={{ borderRadius: '50%' }} />}
                      <span style={{ color: '#6b7280', fontSize: '12px', fontFamily: 'Poppins' }}>{repo.owner}</span>
                      {repo.language && <span className="badge badge-github" style={{ marginLeft: 'auto' }}>{repo.language}</span>}
                    </div>
                    <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '14px', marginBottom: '0.4rem' }}>{repo.repo_name?.split('/')[1]}</div>
                    <p style={{ color: '#6b7280', fontSize: '12px', lineHeight: 1.6, marginBottom: '0.75rem' }}>{truncate(repo.description, 80)}</p>
                    <div style={{ display: 'flex', gap: '1rem', fontSize: '12px', fontFamily: 'Poppins', fontWeight: 600 }}>
                      <span style={{ color: '#f59e0b' }}>⭐ {repo.stars?.toLocaleString()}</span>
                      <span style={{ color: '#9ca3af' }}>🍴 {repo.forks?.toLocaleString()}</span>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </Section>
        </div>

        {/* Right Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

          {/* Ad slot */}
          <div className="ad-slot" style={{ height: 280 }}>Ad Space (300×250)</div>

          {/* AI Tools */}
          <div>
            <div className="section-header">
              <div className="section-title" style={{ fontSize: '1.1rem' }}>🤖 AI Tools</div>
              <a href="/ai-tools" className="btn-outline" style={{ fontSize: '12px', padding: '5px 12px' }}>View all</a>
            </div>
            <div className="divider-aitools section-divider" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {data?.aiTools?.map((tool: AITool) => (
                <a key={tool.slug} href={`/ai-tools/${tool.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
                  <div className="card card-aitools" style={{ padding: '0.875rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                    {tool.image
                      ? <img src={tool.image} alt={tool.name} width={40} height={40} style={{ borderRadius: 8, objectFit: 'cover', flexShrink: 0 }} />
                      : <div style={{ width: 40, height: 40, background: '#ede9fe', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', flexShrink: 0 }}>🤖</div>
                    }
                    <div>
                      <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '13px', marginBottom: '0.2rem' }}>{tool.name}</div>
                      <div style={{ color: '#6b7280', fontSize: '11px', lineHeight: 1.5 }}>{truncate(tool.tagline || tool.description, 60)}</div>
                      {tool.votes > 0 && <div style={{ color: '#7c3aed', fontSize: '11px', fontWeight: 600, marginTop: '0.25rem' }}>▲ {tool.votes}</div>}
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Tech Jobs */}
          <div>
            <div className="section-header">
              <div className="section-title" style={{ fontSize: '1.1rem' }}>💼 Tech Jobs</div>
              <a href="/jobs" className="btn-outline" style={{ fontSize: '12px', padding: '5px 12px' }}>View all</a>
            </div>
            <div className="divider-jobs section-divider" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {data?.jobs?.map((job: Job) => (
                <a key={job.slug} href={`/jobs/${job.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
                  <div className="card card-jobs card-accent-jobs" style={{ padding: '0.875rem' }}>
                    <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '13px', marginBottom: '0.25rem' }}>{job.title}</div>
                    <div style={{ color: '#2563eb', fontSize: '12px', fontWeight: 600, fontFamily: 'Poppins', marginBottom: '0.25rem' }}>{job.company}</div>
                    <div style={{ color: '#6b7280', fontSize: '11px', fontFamily: 'Poppins' }}>📍 {job.location}</div>
                    {(job.salary_min || job.salary) && <div style={{ color: '#16a34a', fontSize: '11px', fontWeight: 600, fontFamily: 'Poppins', marginTop: '0.25rem' }}>{job.salary || formatSalary(job.salary_min, job.salary_max)}</div>}
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Startups */}
          <div>
            <div className="section-header">
              <div className="section-title" style={{ fontSize: '1.1rem' }}>🚀 Startup News</div>
              <a href="/startups" className="btn-outline" style={{ fontSize: '12px', padding: '5px 12px' }}>View all</a>
            </div>
            <div className="divider-startups section-divider" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {data?.startups?.map((item: StartupNews) => (
                <a key={item.slug} href={`/startups/${item.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
                  <div className="card card-startups card-accent-startups" style={{ padding: '0.875rem' }}>
                    <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '13px', marginBottom: '0.4rem', lineHeight: 1.4 }}>{item.title}</div>
                    {item.funding_amount && (
                      <span style={{ background: '#ffedd5', color: '#ea580c', padding: '2px 8px', borderRadius: 999, fontSize: '11px', fontWeight: 700, fontFamily: 'Poppins' }}>💰 {item.funding_amount}</span>
                    )}
                    <div style={{ color: '#9ca3af', fontSize: '11px', fontFamily: 'Poppins', marginTop: '0.4rem' }}>{timeAgo(item.published_at)}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Ad slot */}
          <div className="ad-slot" style={{ height: 240 }}>Ad Space (300×250)</div>
        </div>
      </div>

      {/* CoinGecko Attribution */}
      <div style={{ marginTop: '3rem', paddingTop: '1.5rem', borderTop: '1px solid #e8eaed', display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#9ca3af', fontSize: '12px', fontFamily: 'Poppins' }}>
        Crypto price data provided by{' '}
        <a href="https://www.coingecko.com?utm_source=latestworld&utm_medium=referral" target="_blank" rel="noopener noreferrer" style={{ color: '#16a34a', fontWeight: 600 }}>CoinGecko</a>
      </div>
    </div>
  )
}

function Section({ title, href, accent, badge, children }: { title: string; href: string; accent: string; badge?: string; children: React.ReactNode }) {
  return (
    <section style={{ marginBottom: '3rem' }}>
      <div className="section-header">
        <div className="section-title">
          {title}
          {badge && (
            <span className="live-badge" style={{ marginLeft: 8, fontSize: '10px' }}>
              <span className="live-dot" /> {badge}
            </span>
          )}
        </div>
        <a href={href} className="btn-outline">View all →</a>
      </div>
      <div className={`section-divider divider-${accent}`} />
      {children}
    </section>
  )
}

function LoadingSkeleton() {
  return (
    <div style={{ maxWidth: 1280, margin: '2rem auto', padding: '0 1.25rem' }}>
      {[1, 2, 3].map(i => (
        <div key={i} style={{ marginBottom: '2.5rem' }}>
          <div style={{ height: 28, background: '#f3f4f6', borderRadius: 6, width: 240, marginBottom: '1rem', animation: 'pulse 1.5s infinite' }} />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
            {[1, 2, 3].map(j => <div key={j} style={{ height: 140, background: '#f3f4f6', borderRadius: 12 }} />)}
          </div>
        </div>
      ))}
    </div>
  )
}
