export default function AboutPage() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '3rem 1.25rem' }}>
      <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem' }}>About LatestWorld</h1>
      <div style={{ background: '#e6162d', height: 4, width: 80, borderRadius: 4, marginBottom: '2rem' }} />
      <div style={{ color: '#374151', lineHeight: 1.9, fontFamily: 'Merriweather', fontSize: '15px' }}>
        <p style={{ marginBottom: '1.25rem' }}>LatestWorld.in is an automated technology intelligence platform built for India's growing digital audience. Our system aggregates real-time data from the world's most trusted tech data sources and presents it in a clean, easy-to-read format.</p>
        <p style={{ marginBottom: '1.25rem' }}>We cover cryptocurrency market data, technology news, artificial intelligence tools, open-source software, startup funding, and technology job opportunities — all updated automatically multiple times every day.</p>
        <p style={{ marginBottom: '1.25rem' }}>There is no manual content writing involved. Everything you see is fetched, processed, and displayed automatically through our data pipeline.</p>
        <h2 style={{ fontFamily: 'Poppins', fontWeight: 700, marginBottom: '0.75rem', color: '#0f0f0f' }}>Data Sources</h2>
        <ul style={{ paddingLeft: '1.5rem' }}>
          {[['CoinGecko', 'Cryptocurrency prices and market data'],['GNews API', 'Global technology and startup news'],['GitHub API', 'Trending open source repositories'],['Product Hunt API', 'Latest AI tool launches'],['Adzuna', 'Technology job listings across India']].map(([name, desc]) => (
            <li key={name} style={{ marginBottom: '0.5rem' }}><strong>{name}</strong> — {desc}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}
