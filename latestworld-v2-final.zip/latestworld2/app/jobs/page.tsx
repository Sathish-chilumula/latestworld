'use client'
import { useEffect, useState } from 'react'
import { getJobs, type Job } from '@/lib/supabase'
import { formatSalary, truncate, timeAgo } from '@/utils/helpers'

export default function JobsPage() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => { getJobs(80).then(setJobs).finally(() => setLoading(false)) }, [])

  const filtered = jobs.filter(j =>
    j.title?.toLowerCase().includes(search.toLowerCase()) ||
    j.company?.toLowerCase().includes(search.toLowerCase()) ||
    j.location?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <div style={{ background: 'linear-gradient(135deg, #2563eb, #1d4ed8)', borderRadius: 16, padding: '2rem', marginBottom: '2rem', color: 'white' }}>
        <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem' }}>💼 Tech Jobs in India</h1>
        <p style={{ fontFamily: 'Poppins', fontSize: '14px', opacity: 0.85, marginBottom: '1.25rem' }}>Latest IT & engineering jobs — updated twice daily via Adzuna</p>
        <div style={{ position: 'relative', maxWidth: 500 }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search jobs, companies, locations..." className="search-input" style={{ background: 'white' }} />
        </div>
      </div>

      {loading ? <div style={{ color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
          {filtered.map(job => (
            <a key={job.slug} href={`/jobs/${job.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
              <div className="card card-jobs card-accent-jobs" style={{ padding: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '1rem', marginBottom: '0.25rem', color: '#0f0f0f' }}>{job.title}</div>
                  <div style={{ color: '#2563eb', fontWeight: 600, fontSize: '14px', fontFamily: 'Poppins', marginBottom: '0.35rem' }}>{job.company}</div>
                  <div style={{ display: 'flex', gap: '1.5rem', color: '#6b7280', fontSize: '13px', fontFamily: 'Poppins' }}>
                    <span>📍 {job.location}</span>
                    <span>🕐 {job.job_type?.replace('_', ' ') || 'Full-time'}</span>
                    <span style={{ color: '#9ca3af' }}>{timeAgo(job.created_at)}</span>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  {(job.salary_min || job.salary) && (
                    <div style={{ color: '#16a34a', fontWeight: 700, fontSize: '15px', fontFamily: 'Poppins', marginBottom: '0.5rem' }}>
                      {job.salary || formatSalary(job.salary_min, job.salary_max)}
                    </div>
                  )}
                  <span className="badge badge-jobs">Apply →</span>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}
