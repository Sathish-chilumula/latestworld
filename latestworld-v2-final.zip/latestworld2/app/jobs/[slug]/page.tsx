'use client'
import { useEffect, useState } from 'react'
import { getJob, type Job } from '@/lib/supabase'
import { formatSalary } from '@/utils/helpers'
import { useParams } from 'next/navigation'

export default function JobDetailPage() {
  const params = useParams()
  const [job, setJob] = useState<Job | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params?.slug) getJob(params.slug as string).then(setJob).finally(() => setLoading(false))
  }, [params])

  if (loading) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div>
  if (!job) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Job not found</div>

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "JobPosting",
        "title": job.title,
        "description": job.description,
        "hiringOrganization": { "@type": "Organization", "name": job.company },
        "jobLocation": { "@type": "Place", "address": { "@type": "PostalAddress", "addressLocality": job.location, "addressCountry": "IN" } },
        "employmentType": job.job_type?.toUpperCase() || "FULL_TIME",
        "datePosted": job.created_at,
        "baseSalary": job.salary_min ? { "@type": "MonetaryAmount", "currency": "INR", "value": { "@type": "QuantitativeValue", "minValue": job.salary_min, "maxValue": job.salary_max } } : undefined
      })}} />

      <a href="/jobs" style={{ color: '#6b7280', textDecoration: 'none', fontFamily: 'Poppins', fontSize: '13px' }}>← Back to Jobs</a>

      <div style={{ background: 'linear-gradient(135deg, #dbeafe, #eff6ff)', borderRadius: 16, padding: '2rem', margin: '1.5rem 0', borderLeft: '6px solid #2563eb' }}>
        <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '1.75rem', marginBottom: '0.5rem', color: '#0f0f0f' }}>{job.title}</h1>
        <div style={{ color: '#2563eb', fontWeight: 700, fontSize: '1.1rem', fontFamily: 'Poppins', marginBottom: '0.75rem' }}>{job.company}</div>
        <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', color: '#374151', fontSize: '14px', fontFamily: 'Poppins' }}>
          <span>📍 {job.location}</span>
          <span>🕐 {job.job_type?.replace('_', ' ') || 'Full-time'}</span>
          {(job.salary_min || job.salary) && <span style={{ color: '#16a34a', fontWeight: 700 }}>💰 {job.salary || formatSalary(job.salary_min, job.salary_max)}</span>}
        </div>
      </div>

      {job.description && (
        <div className="card" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
          <h2 style={{ fontFamily: 'Poppins', fontWeight: 700, marginBottom: '1rem', fontSize: '1.1rem' }}>Job Description</h2>
          <div style={{ color: '#374151', lineHeight: 1.8, fontFamily: 'Merriweather', whiteSpace: 'pre-wrap', fontSize: '14px' }}>{job.description}</div>
        </div>
      )}

      {job.apply_url && (
        <a href={job.apply_url} target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ background: '#16a34a', fontSize: '16px', padding: '14px 28px' }}>
          ✅ Apply for this Job →
        </a>
      )}
    </div>
  )
}
