'use client'
import { useEffect, useState } from 'react'
import { getTechNews, type TechNews } from '@/lib/supabase'
import { timeAgo, truncate } from '@/utils/helpers'

export default function NewsPage() {
  const [articles, setArticles] = useState<TechNews[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { getTechNews(60).then(setArticles).finally(() => setLoading(false)) }, [])

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <h1 style={{ fontFamily: 'Poppins', fontWeight: 800, fontSize: '2rem', marginBottom: '0.5rem' }}>📰 Latest Tech News</h1>
      <p style={{ color: '#6b7280', fontFamily: 'Poppins', fontSize: '14px', marginBottom: '2rem' }}>Global technology news — auto-updated every 6 hours</p>

      {loading ? <div style={{ color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div> : (
        <>
          {/* Featured article */}
          {articles[0] && (
            <a href={`/news/${articles[0].slug}`} style={{ textDecoration: 'none', display: 'block', marginBottom: '2rem' }}>
              <div className="card card-news" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', overflow: 'hidden', minHeight: 280 }}>
                {articles[0].image && <img src={articles[0].image} alt={articles[0].title} style={{ width: '100%', height: '100%', objectFit: 'cover', minHeight: 280 }} />}
                <div style={{ padding: '2rem', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                  <span className="badge badge-news" style={{ marginBottom: '1rem', alignSelf: 'flex-start' }}>FEATURED</span>
                  <h2 style={{ fontFamily: 'Poppins', fontWeight: 800, fontSize: '1.5rem', lineHeight: 1.3, color: '#0f0f0f', marginBottom: '0.75rem' }}>{articles[0].title}</h2>
                  <p style={{ color: '#6b7280', fontSize: '14px', lineHeight: 1.7 }}>{truncate(articles[0].description, 160)}</p>
                  <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
                    <span style={{ fontFamily: 'Poppins', fontWeight: 600, fontSize: '13px', color: '#e6162d' }}>{articles[0].source}</span>
                    <span style={{ color: '#9ca3af', fontSize: '12px', fontFamily: 'Poppins' }}>{timeAgo(articles[0].published_at)}</span>
                  </div>
                </div>
              </div>
            </a>
          )}

          {/* Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
            {articles.slice(1).map(item => (
              <a key={item.slug} href={`/news/${item.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
                <div className="card card-news card-accent-news" style={{ height: '100%' }}>
                  {item.image && <img src={item.image} alt={item.title} style={{ width: '100%', height: 180, objectFit: 'cover' }} loading="lazy" />}
                  <div style={{ padding: '1rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                      <span className="badge badge-news">{item.source}</span>
                      <span style={{ color: '#9ca3af', fontSize: '11px', fontFamily: 'Poppins' }}>{timeAgo(item.published_at)}</span>
                    </div>
                    <h3 style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '14px', lineHeight: 1.4, color: '#0f0f0f', marginBottom: '0.5rem' }}>{item.title}</h3>
                    <p style={{ color: '#6b7280', fontSize: '12px', lineHeight: 1.6 }}>{truncate(item.description, 100)}</p>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
