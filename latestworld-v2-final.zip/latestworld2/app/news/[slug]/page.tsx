'use client'
import { useEffect, useState } from 'react'
import { getTechNewsItem, type TechNews } from '@/lib/supabase'
import { useParams } from 'next/navigation'

export default function NewsDetailPage() {
  const params = useParams()
  const [article, setArticle] = useState<TechNews | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params?.slug) getTechNewsItem(params.slug as string).then(setArticle).finally(() => setLoading(false))
  }, [params])

  if (loading) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div>
  if (!article) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Article not found</div>

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "headline": article.title,
        "description": article.description,
        "image": article.image,
        "datePublished": article.published_at,
        "publisher": { "@type": "Organization", "name": article.source },
        "url": `https://latestworld.in/news/${article.slug}`
      })}} />

      <a href="/news" style={{ color: '#6b7280', textDecoration: 'none', fontFamily: 'Poppins', fontSize: '13px' }}>← Back to News</a>

      {article.image && <img src={article.image} alt={article.title} style={{ width: '100%', height: 360, objectFit: 'cover', borderRadius: 16, margin: '1.5rem 0' }} />}

      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginBottom: '1rem' }}>
        <span className="badge badge-news">{article.source}</span>
        <span style={{ color: '#9ca3af', fontSize: '13px', fontFamily: 'Poppins' }}>{article.published_at ? new Date(article.published_at).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' }) : ''}</span>
      </div>

      <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: 'clamp(1.4rem, 3vw, 2rem)', lineHeight: 1.3, marginBottom: '1.5rem', color: '#0f0f0f' }}>{article.title}</h1>

      <div style={{ borderLeft: '4px solid #e6162d', paddingLeft: '1.25rem', marginBottom: '2rem' }}>
        <p style={{ fontFamily: 'Merriweather', fontSize: '1.1rem', lineHeight: 1.8, color: '#374151' }}>{article.description}</p>
      </div>

      <div style={{ background: '#f7f8fa', borderRadius: 12, padding: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <span style={{ color: '#6b7280', fontSize: '14px', fontFamily: 'Poppins' }}>Read the full article at <strong>{article.source}</strong></span>
        <a href={article.url} target="_blank" rel="noopener noreferrer" className="btn-primary">Read Full Story →</a>
      </div>
    </div>
  )
}
