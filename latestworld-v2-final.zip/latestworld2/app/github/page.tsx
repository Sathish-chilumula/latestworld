'use client'
import { useEffect, useState } from 'react'
import { getGithubProjects, type GithubProject } from '@/lib/supabase'
import { truncate, timeAgo } from '@/utils/helpers'

export default function GithubPage() {
  const [repos, setRepos] = useState<GithubProject[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('All')

  useEffect(() => { getGithubProjects(80).then(setRepos).finally(() => setLoading(false)) }, [])

  const langs = ['All', ...Array.from(new Set(repos.map(r => r.language).filter(Boolean))).slice(0, 8)]
  const filtered = filter === 'All' ? repos : repos.filter(r => r.language === filter)

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <div style={{ background: 'linear-gradient(135deg, #dcfce7, #f0fdf4)', border: '2px solid #16a34a30', borderRadius: 16, padding: '2rem', marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '2rem', marginBottom: '0.5rem', color: '#0f0f0f' }}>⭐ Trending GitHub Projects</h1>
        <p style={{ color: '#374151', fontFamily: 'Poppins', fontSize: '14px' }}>Hottest open source repos — updated daily</p>
      </div>

      <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '1.5rem' }}>
        {langs.map(lang => (
          <button key={lang} onClick={() => setFilter(lang)} style={{
            padding: '6px 14px', borderRadius: 999, border: '1.5px solid',
            borderColor: filter === lang ? '#16a34a' : '#e8eaed',
            background: filter === lang ? '#dcfce7' : 'white',
            color: filter === lang ? '#16a34a' : '#6b7280',
            fontFamily: 'Poppins', fontWeight: 600, fontSize: '13px', cursor: 'pointer'
          }}>{lang}</button>
        ))}
      </div>

      {loading ? <div style={{ color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.25rem' }}>
          {filtered.map(repo => (
            <a key={repo.slug} href={`/github/${repo.slug}`} style={{ textDecoration: 'none' }} className="fade-up">
              <div className="card card-github card-accent-github" style={{ padding: '1.25rem', height: '100%' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '0.75rem' }}>
                  {repo.avatar_url && <img src={repo.avatar_url} alt={repo.owner} width={24} height={24} style={{ borderRadius: '50%' }} />}
                  <span style={{ color: '#6b7280', fontSize: '12px', fontFamily: 'Poppins' }}>{repo.owner}</span>
                  {repo.language && <span className="badge badge-github" style={{ marginLeft: 'auto' }}>{repo.language}</span>}
                </div>
                <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '15px', marginBottom: '0.5rem', color: '#0f0f0f' }}>{repo.repo_name?.split('/')[1]}</div>
                <p style={{ color: '#6b7280', fontSize: '13px', lineHeight: 1.6, marginBottom: '1rem', flex: 1 }}>{truncate(repo.description, 100)}</p>
                {repo.topics?.slice(0, 3).map(t => <span key={t} style={{ display: 'inline-block', background: '#f0fdf4', color: '#16a34a', borderRadius: 4, padding: '1px 7px', fontSize: '11px', fontWeight: 600, marginRight: 4, marginBottom: 4 }}>{t}</span>)}
                <div style={{ display: 'flex', gap: '1.5rem', fontSize: '13px', fontFamily: 'Poppins', fontWeight: 600, marginTop: '0.5rem' }}>
                  <span style={{ color: '#f59e0b' }}>⭐ {repo.stars?.toLocaleString()}</span>
                  <span style={{ color: '#9ca3af' }}>🍴 {repo.forks?.toLocaleString()}</span>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  )
}
