'use client'
import { useEffect, useState } from 'react'
import { getGithubProject, type GithubProject } from '@/lib/supabase'
import { useParams } from 'next/navigation'

export default function GithubDetailPage() {
  const params = useParams()
  const [repo, setRepo] = useState<GithubProject | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params?.slug) getGithubProject(params.slug as string).then(setRepo).finally(() => setLoading(false))
  }, [params])

  if (loading) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Loading...</div>
  if (!repo) return <div style={{ padding: '4rem', textAlign: 'center', color: '#6b7280', fontFamily: 'Poppins' }}>Project not found</div>

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '2rem 1.25rem' }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": repo.repo_name,
        "description": repo.description,
        "url": repo.repo_url,
        "applicationCategory": "DeveloperApplication"
      })}} />
      <a href="/github" style={{ color: '#6b7280', textDecoration: 'none', fontFamily: 'Poppins', fontSize: '13px' }}>← Back to GitHub Projects</a>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', margin: '1.5rem 0' }}>
        {repo.avatar_url && <img src={repo.avatar_url} alt={repo.owner} width={56} height={56} style={{ borderRadius: '50%' }} />}
        <div>
          <div style={{ color: '#6b7280', fontFamily: 'Poppins', fontSize: '13px' }}>{repo.owner}</div>
          <h1 style={{ fontFamily: 'Poppins', fontWeight: 900, fontSize: '1.75rem', color: '#0f0f0f' }}>{repo.repo_name?.split('/')[1]}</h1>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
        {[
          { label: 'Stars', value: `⭐ ${repo.stars?.toLocaleString()}`, color: '#f59e0b' },
          { label: 'Forks', value: `🍴 ${repo.forks?.toLocaleString()}`, color: '#2563eb' },
          { label: 'Language', value: repo.language || 'N/A', color: '#16a34a' },
        ].map(s => (
          <div key={s.label} className="card" style={{ padding: '1rem', textAlign: 'center' }}>
            <div style={{ fontFamily: 'Poppins', fontWeight: 700, fontSize: '1.5rem', color: s.color }}>{s.value}</div>
            <div style={{ color: '#9ca3af', fontSize: '12px', fontFamily: 'Poppins' }}>{s.label}</div>
          </div>
        ))}
      </div>
      <div className="card" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <p style={{ color: '#374151', lineHeight: 1.8, fontFamily: 'Merriweather' }}>{repo.description}</p>
        {repo.topics?.length > 0 && (
          <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            {repo.topics.map(t => <span key={t} className="badge badge-github">{t}</span>)}
          </div>
        )}
      </div>
      <a href={repo.repo_url} target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ background: '#16a34a' }}>View on GitHub →</a>
    </div>
  )
}
