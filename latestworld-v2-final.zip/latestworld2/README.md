# 🌐 LatestWorld.in

Fully automated tech & finance content website. Built for Google AdSense earnings.

## ✨ Features
- 💹 Live crypto prices (CoinGecko)
- 📰 Tech & startup news (GNews)
- 🤖 AI tool launches (Product Hunt)
- ⭐ Trending GitHub repos (GitHub API)
- 💼 Tech jobs in India (Adzuna)
- 🚀 Startup funding news (GNews)

## 🎨 Design
- Vibrant light theme (TechCrunch × Moneycontrol style)
- Poppins + Merriweather fonts
- Section colour coding (crypto=gold, news=red, AI=purple, etc.)
- Animated price ticker, hover effects, fade-up animations

## ⚙️ Tech Stack
- **Frontend**: Next.js 14 (TypeScript, App Router, static export)
- **Styling**: Tailwind CSS
- **Database**: Supabase Postgres
- **Hosting**: Cloudflare Pages
- **Cron**: GitHub Actions (4 workflows)

## 📁 Structure
```
/app             — Next.js pages (TypeScript)
/scripts         — Data fetch scripts (run by GitHub Actions)
/lib             — Supabase client + TypeScript types
/utils           — Helper functions
/supabase        — SQL schema
/.github/workflows — 4 cron workflow files
```

## 🚀 Setup
1. Run `supabase/schema.sql` in Supabase SQL Editor
2. Push to GitHub
3. Connect to Cloudflare Pages (build: `npm run build`, output: `out`)
4. Add 2 env vars in Cloudflare Pages
5. Add 9 secrets in GitHub → Settings → Secrets
6. GitHub Actions crons run automatically

See `GITHUB_SECRETS_GUIDE.md` for full instructions.
