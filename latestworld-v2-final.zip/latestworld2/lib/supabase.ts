import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)

// Types
export interface CryptoCoin {
  id: string
  coin_id: string
  name: string
  slug: string
  symbol: string
  price: number
  market_cap: number
  change_24h: number
  change_7d: number
  volume_24h: number
  image: string
  market_cap_rank: number
  updated_at: string
}

export interface Job {
  id: string
  title: string
  slug: string
  company: string
  location: string
  salary: string
  salary_min: number
  salary_max: number
  description: string
  apply_url: string
  job_type: string
  category: string
  created_at: string
}

export interface TechNews {
  id: string
  title: string
  slug: string
  description: string
  image: string
  source: string
  url: string
  category: string
  published_at: string
}

export interface StartupNews {
  id: string
  title: string
  slug: string
  description: string
  image: string
  source: string
  url: string
  funding_amount: string
  company_name: string
  published_at: string
}

export interface GithubProject {
  id: string
  repo_name: string
  slug: string
  owner: string
  description: string
  stars: number
  forks: number
  language: string
  repo_url: string
  avatar_url: string
  topics: string[]
  updated_at: string
}

export interface AITool {
  id: string
  name: string
  slug: string
  description: string
  tagline: string
  website: string
  image: string
  votes: number
  category: string
  launch_date: string
}

// Data fetchers
export async function getCryptoCoins(limit = 50) {
  const { data, error } = await supabase
    .from('crypto_coins')
    .select('*')
    .order('market_cap_rank', { ascending: true })
    .limit(limit)
  if (error) throw error
  return (data || []) as CryptoCoin[]
}

export async function getCryptoCoin(slug: string) {
  const { data, error } = await supabase
    .from('crypto_coins')
    .select('*')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data as CryptoCoin
}

export async function getJobs(limit = 30) {
  const { data, error } = await supabase
    .from('jobs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data || []) as Job[]
}

export async function getJob(slug: string) {
  const { data, error } = await supabase
    .from('jobs')
    .select('*')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data as Job
}

export async function getTechNews(limit = 30) {
  const { data, error } = await supabase
    .from('tech_news')
    .select('*')
    .order('published_at', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data || []) as TechNews[]
}

export async function getTechNewsItem(slug: string) {
  const { data, error } = await supabase
    .from('tech_news')
    .select('*')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data as TechNews
}

export async function getStartupNews(limit = 30) {
  const { data, error } = await supabase
    .from('startup_news')
    .select('*')
    .order('published_at', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data || []) as StartupNews[]
}

export async function getStartupNewsItem(slug: string) {
  const { data, error } = await supabase
    .from('startup_news')
    .select('*')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data as StartupNews
}

export async function getGithubProjects(limit = 30) {
  const { data, error } = await supabase
    .from('github_projects')
    .select('*')
    .order('stars', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data || []) as GithubProject[]
}

export async function getGithubProject(slug: string) {
  const { data, error } = await supabase
    .from('github_projects')
    .select('*')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data as GithubProject
}

export async function getAITools(limit = 30) {
  const { data, error } = await supabase
    .from('ai_tools')
    .select('*')
    .order('votes', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data || []) as AITool[]
}

export async function getAITool(slug: string) {
  const { data, error } = await supabase
    .from('ai_tools')
    .select('*')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data as AITool
}

export async function getHomepageData() {
  const [crypto, news, jobs, aiTools, github, startups] = await Promise.all([
    getCryptoCoins(8),
    getTechNews(6),
    getJobs(6),
    getAITools(6),
    getGithubProjects(6),
    getStartupNews(6),
  ])
  return { crypto, news, jobs, aiTools, github, startups }
}
