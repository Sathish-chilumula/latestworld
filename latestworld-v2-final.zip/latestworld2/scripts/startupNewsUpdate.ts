// scripts/startupNewsUpdate.ts
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

function slug(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').trim().substring(0, 80) + '-' + Date.now().toString(36)
}

async function fetchStartupNews() {
  console.log('🚀 Fetching startup news...')
  const queries = ['startup funding India', 'startup investment series A B C', 'Indian startup raises']

  for (const q of queries) {
    const url = `https://gnews.io/api/v4/search?q=${encodeURIComponent(q)}&lang=en&max=10&apikey=${process.env.GNEWS_API_KEY}`
    const response = await fetch(url)
    if (!response.ok) continue

    const data = await response.json()
    const articles = data.articles || []

    const records = articles.map((a: any) => ({
      title: a.title,
      slug: slug(a.title),
      description: a.description || a.title,
      image: a.image,
      source: a.source?.name || 'Unknown',
      url: a.url,
      published_at: a.publishedAt
    }))

    if (records.length > 0) {
      await supabase.from('startup_news').upsert(records, { onConflict: 'slug', ignoreDuplicates: true })
    }
    await new Promise(r => setTimeout(r, 1000))
  }
  console.log('✅ Startup news updated')
}

fetchStartupNews().catch(err => { console.error('❌ Startup news failed:', err); process.exit(1) })
