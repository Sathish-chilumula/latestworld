// scripts/jobsUpdate.ts
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

function slug(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').trim().substring(0, 80) + '-' + Date.now().toString(36)
}

async function fetchJobs() {
  console.log('💼 Fetching tech jobs from Adzuna...')
  const categories = ['it-jobs', 'engineering-jobs']

  for (const cat of categories) {
    const url = `https://api.adzuna.com/v1/api/jobs/in/search/1?app_id=${process.env.ADZUNA_APP_ID}&app_key=${process.env.ADZUNA_APP_KEY}&results_per_page=20&category=${cat}&content_type=application/json`
    const response = await fetch(url)
    if (!response.ok) continue

    const data = await response.json()
    const jobs = data.results || []

    const records = jobs.map((j: any) => ({
      title: j.title,
      slug: slug(`${j.title}-${j.company?.display_name || ''}`),
      company: j.company?.display_name,
      location: j.location?.display_name,
      salary_min: j.salary_min,
      salary_max: j.salary_max,
      salary: j.salary_min ? undefined : 'Competitive',
      description: j.description,
      apply_url: j.redirect_url,
      job_type: j.contract_time || 'full_time',
      category: cat
    }))

    if (records.length > 0) {
      await supabase.from('jobs').upsert(records, { onConflict: 'slug', ignoreDuplicates: true })
    }
    await new Promise(r => setTimeout(r, 500))
  }
  console.log('✅ Jobs updated')
}

fetchJobs().catch(err => { console.error('❌ Jobs update failed:', err); process.exit(1) })
