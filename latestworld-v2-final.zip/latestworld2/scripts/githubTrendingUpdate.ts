// scripts/githubTrendingUpdate.ts
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

function slug(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').trim().substring(0, 80)
}

async function fetchGitHubTrending() {
  console.log('⭐ Fetching GitHub trending...')

  const date = new Date()
  date.setDate(date.getDate() - 7)
  const dateStr = date.toISOString().split('T')[0]

  const languages = ['javascript', 'python', 'typescript', 'go', 'rust', 'java', 'kotlin', 'swift']
  const allRepos: any[] = []

  const headers: Record<string, string> = {
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'LatestWorld-Bot'
  }
  if (process.env.GITHUB_TOKEN) headers['Authorization'] = `token ${process.env.GITHUB_TOKEN}`

  for (const lang of languages) {
    const url = `https://api.github.com/search/repositories?q=language:${lang}+created:>${dateStr}&sort=stars&order=desc&per_page=10`
    const response = await fetch(url, { headers })
    if (!response.ok) continue
    const data = await response.json()
    allRepos.push(...(data.items || []))
    await new Promise(r => setTimeout(r, 500))
  }

  // Deduplicate
  const seen = new Set()
  const unique = allRepos.filter(r => { if (seen.has(r.id)) return false; seen.add(r.id); return true })

  const records = unique.slice(0, 60).map((repo: any) => ({
    repo_name: repo.full_name,
    slug: slug(repo.full_name),
    owner: repo.owner?.login,
    description: repo.description || 'No description',
    stars: repo.stargazers_count,
    forks: repo.forks_count,
    language: repo.language || 'Unknown',
    repo_url: repo.html_url,
    avatar_url: repo.owner?.avatar_url,
    topics: repo.topics || [],
    updated_at: new Date().toISOString()
  }))

  if (records.length > 0) {
    const { error } = await supabase.from('github_projects').upsert(records, { onConflict: 'repo_name' })
    if (error) throw error
  }

  console.log(`✅ GitHub: ${records.length} repos saved`)
}

fetchGitHubTrending().catch(err => { console.error('❌ GitHub update failed:', err); process.exit(1) })
