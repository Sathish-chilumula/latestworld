// scripts/cryptoUpdate.ts
// Run by GitHub Actions every 6 hours

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

function generateSlug(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim()
}

async function fetchCryptoData() {
  console.log('📊 Fetching crypto data from CoinGecko...')

  const headers: Record<string, string> = { 'Accept': 'application/json' }
  if (process.env.COINGECKO_API_KEY) {
    headers['x-cg-demo-api-key'] = process.env.COINGECKO_API_KEY
  }

  const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h,7d`
  const response = await fetch(url, { headers })
  if (!response.ok) throw new Error(`CoinGecko API error: ${response.status}`)

  const coins = await response.json()

  const records = coins.map((coin: any) => ({
    coin_id: coin.id,
    name: coin.name,
    slug: coin.id,
    symbol: coin.symbol.toUpperCase(),
    price: coin.current_price,
    market_cap: coin.market_cap,
    change_24h: coin.price_change_percentage_24h,
    change_7d: coin.price_change_percentage_7d_in_currency,
    volume_24h: coin.total_volume,
    image: coin.image,
    market_cap_rank: coin.market_cap_rank,
    updated_at: new Date().toISOString()
  }))

  const { error } = await supabase
    .from('crypto_coins')
    .upsert(records, { onConflict: 'coin_id' })

  if (error) throw error
  console.log(`✅ Crypto: ${records.length} coins updated`)
}

fetchCryptoData().catch(err => { console.error('❌ Crypto update failed:', err); process.exit(1) })
