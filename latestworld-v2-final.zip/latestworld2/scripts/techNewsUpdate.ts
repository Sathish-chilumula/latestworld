// scripts/techNewsUpdate.ts
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

function generateSlug(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim().substring(0, 80) + '-' + Date.now().toString(36)
}

async function fetchTechNews() {
  console.log('📰 Fetching tech news from GNews...')

  const queries = ['technology', 'artificial intelligence', 'software']

  for (const q of queries) {
    const url = `https://gnews.io/api/v4/search?q=${encodeURIComponent(q)}&lang=en&country=in&max=10&apikey=${process.env.GNEWS_API_KEY}`
    const response = await fetch(url)
    if (!response.ok) { console.error(`GNews failed for query: ${q}`); continue }

    const data = await response.json()
    const articles = data.articles || []

    const records = articles.map((a: any) => ({
      title: a.title,
      slug: generateSlug(a.title),
      description: a.description || a.title,
      image: a.image,
      source: a.source?.name || 'Unknown',
      url: a.url,
      category: q,
      published_at: a.publishedAt
    }))

    if (records.length > 0) {
      const { error } = await supabase.from('tech_news').upsert(records, { onConflict: 'slug', ignoreDuplicates: true })
      if (error) console.error('Supabase error:', error)
    }

    await new Promise(r => setTimeout(r, 1000))
  }

  console.log('✅ Tech news updated')
}

fetchTechNews().catch(err => { console.error('❌ News update failed:', err); process.exit(1) })
