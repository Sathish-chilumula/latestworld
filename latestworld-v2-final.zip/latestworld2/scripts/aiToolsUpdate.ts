// scripts/aiToolsUpdate.ts
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

function slug(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').trim().substring(0, 80)
}

async function fetchAITools() {
  console.log('🤖 Fetching AI tools from Product Hunt...')

  const query = `query {
    posts(topic: "artificial-intelligence", order: VOTES, first: 20) {
      edges {
        node {
          id name tagline description url votesCount
          thumbnail { url }
          topics { edges { node { name } } }
          createdAt
        }
      }
    }
  }`

  const response = await fetch('https://api.producthunt.com/v2/api/graphql', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.PRODUCTHUNT_TOKEN}`
    },
    body: JSON.stringify({ query })
  })

  if (!response.ok) throw new Error(`Product Hunt API error: ${response.status}`)

  const data = await response.json()
  const posts = data?.data?.posts?.edges || []

  const records = posts.map(({ node: p }: any) => ({
    name: p.name,
    slug: slug(p.name),
    tagline: p.tagline,
    description: p.description || p.tagline,
    website: p.url,
    image: p.thumbnail?.url,
    votes: p.votesCount,
    category: 'AI',
    launch_date: p.createdAt
  }))

  if (records.length > 0) {
    const { error } = await supabase.from('ai_tools').upsert(records, { onConflict: 'slug' })
    if (error) throw error
  }

  console.log(`✅ AI Tools: ${records.length} tools saved`)
}

fetchAITools().catch(err => { console.error('❌ AI Tools update failed:', err); process.exit(1) })
